EN	This file downloaded from http://mydata.biz/ - databases for business.

RU	Этот файл скачан с http://mydata.biz/ru - базы данных для бизнеса.

ES	Este archivo descargado desde http://mydata.biz/es - la base de datos para el negocio.

DE	Diese Datei hier downloaden http://mydata.biz/de - Datenbank für Unternehmen.

FR	Ce fichier est téléchargé à partir de http://mydata.biz/fr - la base de données pour les entreprises.

ZH-CN	这份文件下载 http://mydata.biz/zh_cn -一个数据库业务